Thank you for your Downloading this software, and reading this text. 
However, I'm just poor at English, so it's probably difficult to 
read my text. Sorry!

=====================================================================
[Soft Name] bfl-Works (colin|mcrae|rally|2.0 "bfl"FileTool)
[ Version ] Version 0.0.4
[Comp File] bw004.zip
[CopyRight] CopyRight(c) 2001, Factory J's or Jun Sakai
[   O S   ] MS-Windows95, 98, 2000
[Confirmed] Scratch Build DOS/V PC + MS-Windows2000
[NeededDLL] Tar32.DLL (enclosed)
[ProgLangu] Inprise Borland Delphi 4 Standard
[Soft Type] Freeware
[ Support ] On YellowGarage CMR2 Forum
            http://www.yellowgarage.com/
[Reproduct] Personal reproduct is permitted, 
            but business purpose is not permitted.
            If you can, please mail to me by preference.
=====================================================================

<PURPOSE>
This software splits & reconnects CMPR Format File ("*.bfl") of cmr2.
About CMPR File, vide YellowGarage WebSite.

http://www.yellowgarage.com/titles/cmr2/inside/inside.htm

<Cliche>
Use this software at your own risk!

<OPERATION>
1.Unzip the "bw004.zip" file, then 5 files come out.

	bflWorks.exe	Program File
	bflWorks.ini	Initial File
	ReadMe_E.Txt	This text File
	ReadMe_J.Txt	Manual in Japanese
	Tar32.DLL	DLL File for decompress GNUzip Files

 (If you want to get full Version Tar32.DLL, see the following.)
 ( http://openlab.ring.gr.jp/tsuneo/ )

2.Copy these files to suitable directory.

	bflWorks.exe	suitable
	bflWorks.ini	same directory with bflWorks.exe
	ReadMe_E.Txt	as your like
	ReadMe_J.Txt	can you read?
	Tar32.DLL	Windows System Directory or 
			same directory with bflWorks.exe

 (When you disappointingly uninstall bfl-Works,
   you have to delete these files only.)

3.Execute !

4.To Split
4.1."SplitOffDir" is the Dir to put the Unzip and split files.
    Default directory is "c:\tmp". You can change, and it's
    automatically saved into Initial File.

4.2.Drag & Drop "bfl" file(s) onto bfl-Works window.
    If D&Ded file is compressed by GNUzip, it's automatically
    Unziped and splited.

4.3."bfl-Works" makes directory for splitted files and "bwd" file(s).

  ---Example---
        Drag & Drop : foca1.bfl
        SplitOffDir : c:\tmp

         Maked Dir  : c:\tmp\foca1\
         Maked bwd  : c:\tmp\foca1.bwd
  -------------

   Attention: The bwd file is neccessity to connecting files.

4.4.The program checks whether right bfl file or not.
    *.c3d files have same CMPR headder, but it's cannot be splitted.


5.To Connect
5.1.Drag & Drop "bwd" file(s), which made by bfl-Works.
    If all Dir & files are exist, bfl file(s) is made
    in same directory with the bwd file.

6.Special Thanks
  Mr.dontcut: bfl-Works named by him, and debugs
  Mr.KO: He give me a lot of hints for programming.
  Mr.kem, mog, Kinoppy, and YellowGarage Stuff.

  And you for DownLoaded.

  Jan/15/2001						YellowGarage
							Factory J's
							 Jun Sakai
						    pxl06663@nifty.ne.jp

---Version------------------------------------------

Version 0.0.1   Jan/13/2001
-First Version was Born.

Version 0.0.2   Jan/13/2001
-Debugged the probrem, the GNUziped bfl file in same directory
   break down.
-Debugged the probrem, temporary directory and files are not deleted.
-Change the interface language.
-Deleted the numbers of message for debug.

Version 0.0.3   Jan/14/2001
-Debugged the probrem, when D&D over 2 files,
   mistake overwright message is showed.
-Debugged the probrem, After Unzip procedure, the bfl-file is occupied
   by bfl-Works.
-Postpone to compress connected bfl file(s) with GNUzip.
-Change the way to show message "Done".

Version 0.0.4   Jan/15/2001
-Rechange the interface language to English.

----------------------------------------------------
